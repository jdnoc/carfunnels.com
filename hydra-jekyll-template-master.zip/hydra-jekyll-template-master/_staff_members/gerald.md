---
name: Gerald Freeman
position: Sales
image_path: https://source.unsplash.com/collection/139386/603x603?a=.png
twitter: CloudCannonApp
blurb: Gerald loves going to bike rides and spending time with his family.
---
